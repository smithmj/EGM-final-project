setwd("~/Antibiotic Cycling") 
source(file="cycling.R")

random_states <- as.matrix(read.table("adaptive_cycling/tables/random_initial_states_1000.txt", sep=",", nrows=1000))

sequences <- c()
avg_growth_rates <- c()
max_growth_rates <- c()
final_state_matrix <- matrix(0, nrow=1000, ncol=16)
for(i in 1:nrow(random_states)){
  print(i)
  adaptive_list <- adaptive_cycling(random_states[1,], 500)
  class(adaptive_list)
  adaptive_seq <- adaptive_list[[1]]
  sequences <- c(sequences, adaptive_seq)
  seq_growth_rates <- as.numeric(adaptive_list[[2]])
  avg_growth_rates <- c(avg_growth_rates, mean(seq_growth_rates[400:500]))
  max_growth_rates <- c(max_growth_rates, max(seq_growth_rates[400:500]))
  final_state <- adaptive_list[[3]]
  print(final_state)
  final_state_matrix[i,] <- final_state
}

sequences_table <- as.table(matrix(sequences, nrow=1000))
print("mean growth rates:")
print(mean(avg_growth_rates))
print("max growth rates:")
print(mean(max_growth_rates))
avg_final_state <- colMeans(final_state_matrix)
print(avg_final_state)

#for each state, need to save the equilibrium growth rate over the last 100,
#the max growth rate over the last 100, and the sequence so that you
#can find the onset step manually later